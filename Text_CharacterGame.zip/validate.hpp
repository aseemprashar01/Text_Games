/********************************************************************************************
** Name: Aseem Prashar
** Date: 1/14/18
** Description: validate.hpp is the validate function prototype definition file.
********************************************************************************************/
#ifndef VALIDATE_HPP
#define VALIDATE_HPP

int Validate();
bool validate(char[], int);
double DValidate();
bool dvalidate(char[], int);

#endif
