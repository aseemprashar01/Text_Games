/********************************************************************************************
** Name: Aseem Prashar
** Date: 2/08/18
** Description: BlueMen.hpp is the BlueMen class specification file.
********************************************************************************************/
#include"Chracter.hpp"

#ifndef BLUEMEN_HPP
#define BLUEMEN_HPP

class BlueMen :public Chracter
{
	int die;
	int defenseDie;    // Tracks which die is being used by the blue men.1-1d6,2- 2d6, 3- 3d6.
public:
	BlueMen();
	BlueMen(string n);
	int Attack();
	int Defense();
	int dieRoll();
	double getStrength();
	void attackType();
	void defendType();
	void setStrength(double);
	void setAttack(int);
	void recovery();
};
#endif

