/**************************************************************************
** Name: Aseem Prashar
** Date: 02/08/18
** Description: Barbarian.cpp is the Animal class implementation file.
***************************************************************************/

#include"Barbarian.hpp"
#include<ctime>
#include<cstdlib>
#include<iostream>

using namespace std;


Barbarian::Barbarian()               // Constructor.       
{
	attack = 0;
	defense = 0;
	armor = 0;
	strengthPoints = 12;
	type = "Barbarian";
}

Barbarian::Barbarian(string n)      // Constructor with a parameter for name.
{
	attack = 0;
	defense = 0;
	armor = 0;
	strengthPoints = 12;
	setName(n);
	type = "Barbarian";
}

/*****************************************************************************************************
						Barbarian::Attack
This function returns the attack die roll.

******************************************************************************************************/

int Barbarian::Attack()
{
	attack = 0;                     // attack should not be modified in calls.
	for (int i = 0; i < 2; i++)
	{
		attack += dieRoll();
	}
	return attack;
}
/*****************************************************************************************************
						Barbarian::Defense
This function returns the defense die roll.

******************************************************************************************************/

int Barbarian::Defense()
{
	defense = 0;                      // defense should not be modified in calls.
	for (int i = 0; i < 2; i++)
	{
		defense += dieRoll();
	}
	return defense;

}
/*****************************************************************************************************
Barbarian::dieRoll
This function returns a random number between 1 and 6.

******************************************************************************************************/

int Barbarian::dieRoll()
{
	//srand(time(NULL));  // seed the random number for rand.)
	int num;

	num = rand() % 6 + 1; // random number between 1 and 6.

	//cout << "Num is : " << num << endl;

	return num;
}


/*****************************************************************************************************
Barbarian::getStrength
This function returns strength.

******************************************************************************************************/
double Barbarian::getStrength()
{
	return strengthPoints;
}
/*****************************************************************************************************
Barbarian::attackType()
This function displays attacker.

******************************************************************************************************/
void Barbarian::attackType()
{
	cout << "The attack type is : Barbarian" << endl;
}

/*****************************************************************************************************
Barbarian::defendType
This function displays defender.
******************************************************************************************************/
void Barbarian::defendType()
{
	cout << "The defense type is : Barbarian" << endl;
}


/*****************************************************************************************************
Barbarian::setStrength
This function takes an arguement to set strength.
******************************************************************************************************/
void Barbarian::setStrength(double strength)
{
	strengthPoints = strength;
}

/*****************************************************************************************************
Barbarian::setAttack
This function takes an arguement to set attack.
******************************************************************************************************/
void Barbarian::setAttack(int a)
{
	attack = a;
}
/******************************************************************************************************
								Barbarian::recovery
This function generates a random number between 1 and 10 and based on that the player gains strength back.
Ex : 4 means 40% recovery from the damage to the strength.

*******************************************************************************************************/


void Barbarian::recovery()                               //generate a random number to calculate recovery.
{
	int num = 0;
	
	if ((12 - getStrength()) > 0)
	{
		num = rand() % 10 + 1;                          // generate a random number between 1 and 10.
		//num = 10;
		//cout << "num is :" << num;
		double newStrength = getStrength()+ ((12 - getStrength())*(num * 0.1));
		//cout << "New strength is : " << newStrength << endl;
		setStrength(newStrength);
	}
}