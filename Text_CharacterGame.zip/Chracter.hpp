
/********************************************************************************************
** Name: Aseem Prashar
** Date: 2/08/18
** Description: Chracter.hpp is the Chracter class specification file.
********************************************************************************************/



#ifndef CHRACTER_HPP
#define CHRACTER_HPP

#include<string>
using namespace std;

class Chracter
{
protected:

	int attack,
		defense,
		armor,
		dieScore;
	double strengthPoints;
	string name;                                                // to add name of the chracter.
	string type;                                                // to store the type of the chracter.
public:
	Chracter();
	Chracter(string n);
	virtual int Attack()=0;
	virtual int Defense()=0;
	virtual int dieRoll()=0;
	int getAttack() { return attack; };
	int getDefense() { return defense; };
	int getArmor() { return armor; };
	void  setName(string);
	string getName();
	string getType();                                    // This returns chracter type.
	virtual double getStrength()=0 ;
	virtual void attackType() = 0;
	virtual void defendType() = 0;
	virtual void setStrength(double) =0;
	virtual void setAttack(int) = 0;
	virtual void recovery() = 0;                           // at the end the winner has to recover.
	

};
#endif