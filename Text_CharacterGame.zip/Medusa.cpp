/**************************************************************************
** Name: Aseem Prashar
** Date: 02/08/18
** Description: Medusa.cpp is the Medusa class implementation file.
***************************************************************************/

#include"Medusa.hpp"
#include<ctime>
#include<cstdlib>
#include<iostream>

using namespace std;


Medusa::Medusa()                                                // Constructor.
{
	attack = 0;
	defense = 0;
	armor = 3;
	strengthPoints = 8;
	type = "Medusa";
}

Medusa::Medusa(string n)                                                // Constructor.
{
	attack = 0;
	defense = 0;
	armor = 3;
	strengthPoints = 8;
	setName(n);
	type = "Medusa";
}

/*****************************************************************************************************
Medusa::Attack
This function returns the attack die roll.

******************************************************************************************************/
int Medusa::Attack()
{
	//2d6 
	attack = 0;
	for (int i = 0; i < 2; i++)
	{
		attack += dieRoll();
		//attack += 6;
	}
	if (attack == 12)
	{
		//cout << "Medusa glare is active." << endl;
		attack = 500;
	}
	return attack;
}

/*****************************************************************************************************
Medusa::Defense
This function returns the defense die roll.

******************************************************************************************************/
int Medusa::Defense()
{
	//1d6.
	 
	defense = dieRoll();
	return defense;
}

/*****************************************************************************************************
Medusa::dieRoll
This function returns a random number between 1 and 6.

******************************************************************************************************/

int Medusa::dieRoll()
{
	//srand(time(NULL));  // seed the random number for rand.)
	int num;
	
	num = rand() % 6 + 1; // random number between 1 and 6.
	//num = 6; // Test for glare.
	//cout << "Num is : " << num << endl;
	
	return num;

}



/*****************************************************************************************************
Medusa::getStrength
This function returns strength.

******************************************************************************************************/
double Medusa::getStrength()
{
	return strengthPoints;
}

/*****************************************************************************************************
Medusa::attackType()
This function displays attacker.

******************************************************************************************************/
void Medusa::attackType()
{
	cout << "The attack type is : Medusa" << endl;
}

/*****************************************************************************************************
Medusa::defendType
This function displays defender.
******************************************************************************************************/
void Medusa::defendType()
{
	cout << "The defense type is : Medusa" << endl;
}

/*****************************************************************************************************
Medusa::setStrength
This function takes an arguement to set strength.
******************************************************************************************************/
void Medusa::setStrength(double strength)
{
	strengthPoints = strength;
}

/*****************************************************************************************************
Medusa::setAttack
This function takes an arguement to set attack.
******************************************************************************************************/
void Medusa::setAttack(int a)
{
	attack = a;
}
/******************************************************************************************************
								Medusa::recovery
This function generates a random number between 1 and 10 and based on that the player gains strength back.
Ex : 4 means 40% recovery from the damage to the strength.

*******************************************************************************************************/
void Medusa::recovery()
{
	int num = 0;

	if ((8 - getStrength()) > 0)
	{
		num = rand() % 10 + 1;                          // generate a random number between 1 and 10.
														//num = 5;
		//cout << "num is :" << num;
		double newStrength = getStrength() + ((8 - getStrength())*(num * 0.1));
		//cout << "New strength is : " << newStrength << endl;
		setStrength(newStrength);
	}
}