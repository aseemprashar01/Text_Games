/********************************************************************************************
** Name: Aseem Prashar
** Date: 2/12/18
** Description: DoubleNode.hpp is the DoubleNode and Node class specification file.
********************************************************************************************/


#ifndef QUEUENODE_HPP
#define QUEUENODE_HPP

#include"Chracter.hpp"
#include<string>
struct QueueNode
{
	
	Chracter *player = NULL;                             // pointer to a chracter.
	QueueNode *next;
	QueueNode *prev;

};

class Queue
{
private:
	QueueNode *head;
	
public:
	Queue();
	~Queue();
	bool isEmpty();
	void addBack(Chracter *p);
	Chracter* getFront();
	void removeFront();
	void printQueue();

};
#endif

