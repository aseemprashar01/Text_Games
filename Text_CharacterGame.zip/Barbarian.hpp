/********************************************************************************************
** Name: Aseem Prashar
** Date: 2/08/18
** Description: Barbarian.hpp is the Barbarian class specification file.
********************************************************************************************/
#include"Chracter.hpp"

#ifndef BARBARIAN_HPP
#define BARBARIAN_HPP

class Barbarian :public Chracter
{

public:
	Barbarian();
	Barbarian(string n);
	int Attack();
	int Defense();
	int dieRoll();
	double getStrength();
	void attackType();
	void defendType();
	void setStrength(double);
	void setAttack(int);
	void recovery();
};
#endif
