/********************************************************************************************
** Name: Aseem Prashar
** Date: 2/08/18
** Description: Menu.hpp is the Menu class specification file.
********************************************************************************************/
#include"Chracter.hpp"
#include"QueueNode.hpp"

#ifndef MENU_HPP
#define MENU_HPP

void displayMenu();
void createTeam1(int &, Queue &);
void createTeam2(int &, Queue &);
void menuplay( Chracter *, Chracter *);
int damageP1(Chracter *, Chracter *);
int damageP2(Chracter *, Chracter *);
void displayStatsP2(Chracter *, Chracter *);
void displayStatsP1(Chracter *, Chracter *);
void gameMenu();
void createLoser(Chracter *p, Queue &loser);

#endif
