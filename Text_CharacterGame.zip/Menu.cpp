#include"Menu.hpp"
#include<iostream>
#include"Vampire.hpp"
#include"Medusa.hpp"
#include"Chracter.hpp"
#include"Barbarian.hpp"
#include"BlueMen.hpp"
#include"HarryPotter.hpp"
#include<ctime>
#include<cstdlib>
#include<string>


using namespace std;

void displayMenu()
{
	cout << endl;
	cout << "Select a player" << endl;
	cout << "1  Vampire" << endl;
	cout << "2  Barbarian" << endl;
	cout << "3  Blue Men" << endl;
	cout << "4  Medusa" << endl;
	cout << "5  Harry Potter" << endl;
}


/***************************************************************************************************************************************************
menuplay function does the following:
It starts the game by creating player 1 and player 2 based on the given options:
1. If user selects 1 Vampire object is created.
2. If user selects 2 Barbarian object is created.
3. If user selects 3 Blue Men object is created.
4. If user selects 4 Medusa object is created.
5. If user selects 5 HarryPotter object is created.

Special abilities:
1.Vampire: Charm: Vampires can charm an opponent into not attacking. For a given attack there is a 50% chance that their opponent does not actually attack them.
2. BlueMen: Mob: Blue Men are actually a swarm of small individuals. For every 4 points of damage, they lose one defense die.
For example, if they have a strength of 8, they would have 2d6 for defense.
3. Glare: If a Medusa rolls a 12 when attacking then the target instantly gets turned into stone and Medusa wins! 
If Medusa uses Glare on Harry Potter on his first life, then Harry Potter comes back to life.
4. Hogwarts: If Harry Potter's strength reaches 0 or below, he immediately recovers and his total strength becomes 20. If he were to die again, then he�s dead.


Special cases for special ablities are goverened by these rules:
1.If Medusa uses �glare� on Harry Potter on his first life, then Harry Potter comes back to life after using �hogwarts�.
2.If the Vampire�s �charm� ability activates when Medusa uses �glare�, the Vampire�s charm trumps Medusa�s glare.


Also, strength point updated after damage calculation of the defender in each turn.

*********************************************************************************************************************************************/


void menuplay(Chracter *p1,Chracter *p2 )                 // add variables for winnings and losses counting.
{
	

	//this code segment will be common for all the  above if conditions.
	int strengthP1 = 0;
	int strengthP2 = 0;
	int numRound = 0;
	bool playerDead = false;
	char ch;
	
	
	while (playerDead == false)
	{

		numRound++; // Counts number of rounds played
				
		for (int i = 0; i < 2; i++)                                           // Each round has two turns.
		{

			if (i == 0)                         // Turn 1 player 1 attacks.
			{
				
				//cout << "This is round: " << numRound << "turn no: " << i + 1 << endl;
				//displayStatsP2(p1, p2);
				p1->Attack();
				p2->Defense();
				//cout << "The damage is: " << damageP2(p1, p2) << endl;

				strengthP2 = p2->getStrength() - damageP2(p1, p2);               //Update player 2 strength when player 1 attacks.
				p2->setStrength(strengthP2);

				//cout << "The strength point of Player 2 after damage is :" << p2->getStrength() << endl;

						
				if (p2->getStrength() <= 0)
				{
					playerDead = true;
					//cout << "Player 2 is dead." << endl;
					break;
				}
				

			}

			else                                  // Turn 2 player2 attacks.
			{
				//cout << "This is round: " << numRound << "turn no: " << i + 1 << endl;
				//displayStatsP1(p1, p2);
				p2->Attack();
				p1->Defense();
				strengthP1 = p1->getStrength() - damageP1(p1, p2);               //Update player 2 strength when player 1 attacks.

				//cout << "The damage is: " << damageP1(p1, p2) << endl;
				p1->setStrength(strengthP1);

				//cout << "The strength point of Player 1 after damage is :" << p1->getStrength() << endl;
				
				
				
				if (p1->getStrength() <= 0)
				{
					playerDead = true;
					//cout << "Player 1 is dead." << endl;
					break;
				}
				//cout << "Enter a chracter to start next round." << endl;
				//cin >> ch;
			}

		}


	}

	return;
}
	
	
/********************************************************************************************************************************

damageP2 funtion has a return type of integer and takes two arguements pointer to chracter1 and chracter2.
It then computes the damage to player2 using the formula:
Damage= Player1 attack - Player2 Defense - Player2 Armor.
If damage<0 then damage is rounded to zero.

*********************************************************************************************************************************/

int damageP2(Chracter *p1, Chracter *p2)         // p1-attacks , p2- defends.
{
	int result = p1->getAttack() - p2->getDefense() - p2->getArmor();
	if (result < 0)
	{
		result = 0;             // as damage can't be negative.
	}
	return result;
}
/********************************************************************************************************************************

damageP1 funtion has a return type of integer and takes two arguements pointer to chracter1 and chracter2.
It then computes the damage to player2 using the formula:
Damage= Player2 attack - Player1 Defense - Player1 Armor.
If damage<0 then damage is rounded to zero.

*********************************************************************************************************************************/

int damageP1(Chracter *p1, Chracter *p2)         // p1-attacks , p2- defends.
{
	int result = p2->getAttack() - p1->getDefense() - p1->getArmor();
	if (result < 0)
	{
		result = 0;             // as damage can't be negative.
	}
	return result;
}

/********************************************************************************************************************************

displayStatsP2 takes two arguements pointer to player1 and player2.
It then dispalays the following information:
1. Player 1 attacker type.
2. Player 2 defender type.
3. Player 2 armor.
4. Player 2 strength point.
5. Player 1 attack die roll.
6. Player 2 defense die roll.

*********************************************************************************************************************************/

void displayStatsP2(Chracter *p1, Chracter *p2)
{
	p1->attackType();
	p2->defendType();
	cout << "Player2 armor is: " << p2->getArmor() << endl;
	cout << "Player2 strength point is: " << p2->getStrength() << endl;
	cout << "Player1 attack is: " << p1->Attack()<< endl;
	cout << "Player2 defense is: " << p2->Defense() << endl;
	                                                                                     
}

/********************************************************************************************************************************

displayStatsP1 takes two arguements pointer to player1 and player2.
It then dispalays the following information:
1. Player 2 attacker type.
2. Player 1 defender type.
3. Player 1 armor.
4. Player 1 strength point.
5. Player 2 attack die roll.
6. Player 1 defense die roll.

*********************************************************************************************************************************/

void displayStatsP1(Chracter *p1, Chracter *p2)
{

	p2->attackType();
	p1->defendType();
	cout << "Player1 armor is: " << p1->getArmor() << endl;
	cout << "Player1 strength point is: " << p1->getStrength() << endl;
	cout << "Player2 attack is: " << p2->Attack() << endl;
	cout << "Player1 defense is: " << p1->Defense() << endl;
	
}

/************************************************************************************************
										gameMenu

This function displays a menu to the user again after the end of the tournament.

*************************************************************************************************/

void gameMenu()
{
	cout << endl;
	cout << "Select an option from the menu." << endl;
	cout << "1. Play Again." << endl;
	cout << "2. Quit Game." << endl;
}

/***************************************************************************************************
									createTeam1

This function creates a queue for team 1. 
For each player being entered in the queue. User is prompted to provide a name for that player.

****************************************************************************************************/
void createTeam1(int &ch1, Queue &team1)
{
	//Chracter *p1;
	string name;
	cin.ignore();
	cout << "Enter player name." << endl;
	getline(cin, name, '\n');
	if (ch1 == 1)
	{
		//p1 = new Vampire;
		team1.addBack(new Vampire(name));
	}
	else if (ch1 == 2)
	{
		//p1 = new Barbarian;
		team1.addBack(new Barbarian(name));
	}
	else if (ch1 == 3)
	{
		//p1 = new BlueMen;
		team1.addBack(new BlueMen(name));
	}
	else if (ch1 == 4)
	{
		//p1 = new Medusa;
		team1.addBack(new Medusa (name));
	}
	else 
	{
		//p1 = new HarryPotter;
		team1.addBack(new HarryPotter (name));
	}


}

/***************************************************************************************************
										createTeam2

This function creates a queue for team 2.
For each player being entered in the queue. User is prompted to provide a name for that player.

****************************************************************************************************/
void createTeam2(int &ch2, Queue &team2)
{
	//Chracter *p;
	string name;
	cin.ignore();
	cout << "Enter player name." << endl;
	getline(cin, name,'\n');

	if (ch2 == 1)
	{
		//p = new Vampire;
		team2.addBack(new Vampire (name));
		
	}
	else if (ch2 == 2)
	{
		//p = new Barbarian;
		team2.addBack(new Barbarian (name));
	}
	else if (ch2 == 3)
	{
		//p = new BlueMen;
		team2.addBack(new BlueMen (name));
	}
	else if (ch2 == 4)
	{
		//p = new Medusa;
		team2.addBack(new Medusa (name));
	}
	else
	{
		//p = new HarryPotter;
		team2.addBack(new HarryPotter(name));
	}


}
/***************************************************************************************************
										createLoser

This function creates a queue for Loser.
Whenever a player loses a match from team 1 or team 2 it gets added to this pool.

****************************************************************************************************/
void createLoser(Chracter *p, Queue &loser)
{
	loser.addBack(p);
}
