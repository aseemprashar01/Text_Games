#include"Chracter.hpp"


Chracter::Chracter()                       //Constructor.
{
	attack = 0;
	defense = 0;
	armor = 0;
	strengthPoints = 0;
	name = "";
	type = "";

}
Chracter::Chracter(string n)              // Constructor with one parameter for name.
{
	attack = 0;
	defense = 0;
	armor = 0;
	strengthPoints = 0;
	setName(n);
	type = "";
}

/*****************************************************************************************
									Chracter::setName

This function sets the name of the chracter.

******************************************************************************************/

void Chracter::setName(string charName)
{
	this->name = charName;
}

/*****************************************************************************************
									Chracter::getName

This function returns the name of the chracter.

******************************************************************************************/
string Chracter::getName()
{
	return this->name;
}

/*****************************************************************************************
									Chracter::getType

This function returns the chracter type.

******************************************************************************************/
string Chracter::getType()
{
	return this->type;
}

