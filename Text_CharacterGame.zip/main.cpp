
#include"Chracter.hpp"
#include"validate.hpp"
#include"Menu.hpp"                             
#include<iostream>
#include"QueueNode.hpp"
#include<ctime>
#include<cstdlib>
#include<string>


using namespace std;
/********************************************************************
		displayGameMenu
This function displays the initial menu for the game. 

********************************************************************/

void displayGameMenu()
{
	cout << "1. Play Game." << endl;
	cout << "2. Exit." << endl;
}

int main()
{
	displayGameMenu();
	int gameChoice;
	cout << "Please select an option from the menu.Hit 1 to Play and 2 to Exit." << endl;
	gameChoice = Validate();
	while (gameChoice < 1 || gameChoice > 2)
	{
		cout << "Please reenter your choice.Hit 1 to Play and 2 to Exit."<<endl;
		gameChoice = Validate();
	}
	if (gameChoice == 2)
	{
		cout << "Game will now exit." << endl;
		return 0;

	}
		
	int choice = 1;                                                   // Variable initialization.
	Queue team1, team2, loser;
	int team1Score, team2Score,numFighter,ch1,ch2;
	int userChoice;
	char ch;
	
	while (choice == 1)
	{
		srand (time(NULL));                                    // to seeed the random functions.
		team1Score = 0;
		team2Score = 0;
		
		cout << "Enter the number of fighters you want to start with for each team. Choose any number between 1 to 100." << endl;
		numFighter = Validate();
		while (numFighter < 1 || numFighter >100)
		{
			cout << "The number of fighter can be between 1 and 100." << endl;
			numFighter = Validate();
		}
		
		for (int i = 0; i < numFighter; i++)                                                         // We have to create queues.
		{
			cout << endl;
			cout << "Select Player " << i + 1 << " for team1 . Hit any number between 1 to 5." << endl;                        // User prompted to select player1.
			displayMenu();
			ch1 = Validate();
			while (ch1 < 1 || ch1 > 5)
			{
				cout << "Invalid choice.Enter a number between 1 and 5. " << endl;
				ch1 = Validate();

				//cout << "Enter the name of the chracter." << endl;

			}
			createTeam1(ch1, team1);               //  create team 1 lineup.

			cout << "Select Player " << i + 1 << " for team2. Hit any number between 1 to 5." << endl;                        // User prompted to selected player2.
			displayMenu();

			ch2 = Validate();
			while (ch2 < 1 || ch2 > 5)
			{
				cout << "Invalid choice.Enter a number between 1 and 5. " << endl;
				ch2 = Validate();


			}
			createTeam2(ch2, team2);                    // create team 2 lineup.

		}

		cout << "Team1 lineup is: " << endl;
		team1.printQueue();
		cout << endl;
		cout << "Team2 lineup is: " << endl;
		team2.printQueue();
		cout << endl;
		//after the teams have been created now we need to start the match.
				     
		Chracter *player1 = NULL, *player2 = NULL;

		while (!(team1.isEmpty()) && !(team2.isEmpty()))                              // till the time any of the queue is not empty keep running the game.
		{
			player1 = team1.getFront();
			player2 = team2.getFront();

			cout << "Team 1 "<< player1->getType()<< " "<< player1->getName() << " VS " << " Team 2 "<< player2->getType()<< " "<< player2->getName() << endl; // display match info.

			menuplay(player1, player2);               // start a match between players.

			
			
			if (player1->getStrength() <= 0)          // player 1 is dead. Player2 won the match.
			{
				cout <<player2->getType()<<" "<< player2->getName() << " won the match." << endl;
				team1.removeFront();                  // player1 is removed from team1.
				createLoser(player1, loser);
				team2.removeFront();
				player2->recovery();
				team2.addBack(player2);
				team1Score--;                          // for losses score decreased by 1.
				team2Score += 2;                      // for wins score increase by 2.       
			}

			else                                     // player 2 is dead. Player1 won the match.
			{
				cout << player1->getType() << " " << player1->getName() << " won the match." << endl;
				team2.removeFront();                  // player1 is removed from team1.
				createLoser(player2, loser);									  //createLoser(player1);
				team1.removeFront();
				player1->recovery();
				team1.addBack(player1);
				team2Score--;                          // for losses score decreased by 1.
				team1Score += 2;                      // for wins score increase by 2.    

			}
			cout << "Enter a chracter to continue." << endl;
			cin >> ch;

		}
		// Now the game is over as one of the queue is empty.
		//delete player1;
		//delete player2;
		player1 = NULL;
		player2 = NULL;
		if (team1Score > team2Score)
		{
			cout << "Team 1 won the tournament with points: " << team1Score << endl;
		}

		else if (team2Score > team1Score)
		{
			cout << "Team 2 won the tournament with points: " << team2Score << endl;
		}
		else
		{
			cout << "The tournament is a tie. Both team got points: " << team1Score << endl;
		}
		userChoice = 0;
		cout << "Do you want to display the loser list.1 for Yes 2 for No." << endl;
		userChoice = Validate();

		while (userChoice < 1 || userChoice >2)
		{
			cout << "Please enter a valid choice. Hit 1 to Play again and 2 to Quit." << endl;
			userChoice = Validate();
		}

		if (userChoice == 1)
		{
			cout << "The loser lineup is: " << endl;
			loser.printQueue();
		}

		gameMenu();
		cout << " Please Hit 1 to Play again and 2 to Quit" << endl;
		choice = Validate();

		while (choice < 1 || choice >2)
		{
			cout << "Please enter a valid choice. Hit 1 to Play again and 2 to Quit." << endl;
			choice = Validate();
		}
		if (choice == 2)
		{
			cout << "You chose to quit the game." << endl;
		}
		team1.~Queue();
		team2.~Queue();
		loser.~Queue();
		

	}
		
		
//system("Pause");

return 0;
}
