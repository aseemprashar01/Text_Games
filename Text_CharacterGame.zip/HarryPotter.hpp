/********************************************************************************************
** Name: Aseem Prashar
** Date: 2/08/18
** Description: HarryPotter.hpp is the HarryPotter class specification file.
********************************************************************************************/

#include"Chracter.hpp"

#ifndef HARRYPOTTER_HPP
#define HARRYPOTTER_HPP

class HarryPotter :public Chracter
{
	int life ;
public:
	HarryPotter();
	HarryPotter(string n);
	int Attack();
	int Defense();
	int dieRoll();
	double getStrength();
	void attackType();
	void defendType();
	void setStrength(double);
	void setAttack(int);
	void recovery();
};
#endif