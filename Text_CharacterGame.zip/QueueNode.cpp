/**************************************************************************
** Name: Aseem Prashar
** Date: 02/12/18
** Description: QueueNode.cpp is the QueueNode and QueueNode struct implementation file.
***************************************************************************/
#include<iostream>
using namespace std;

#include"QueueNode.hpp"

Queue::Queue()                                  // Constructor.
{
	head = NULL;
	
}
Queue::~Queue()                                //Destructor.
{
	QueueNode *temp = head;
	while (!isEmpty())
	{
		delete head->player;
		removeFront();

	}
	
}

/********************************************************************************************

								Queue::isEmpty()
This function checks if the  queue is empty and returns true for empty queue and false otherwise.
***********************************************************************************************/
bool Queue::isEmpty()
{
	if (head == NULL)
	{
		return true;
	}
	else
	{
		return false;
	}
}


/********************************************************************************************

								Queue::addBack()              // This description will be modified as well.
This function takes a user-inputted Chracter pointer, creates a QueueNode with user-inputted pointer
, and appends it to the back of the list.
***********************************************************************************************/
void Queue::addBack(Chracter *p)
{
	if (isEmpty())
	{
		head = new QueueNode;
		head->next = head;
		head->prev = head;
		head->player = p;
	}
	else 
	{
		QueueNode *temp = head->prev;  // This will give us the last node.
		QueueNode *temp1 = new QueueNode;    // add a new node at the end.
		temp1->player = p;
		temp1->next = head;
		temp1->prev = temp;
		temp->next = temp1;
		head->prev = temp1;
	}
}



/********************************************************************************************

								Queue::getFront
This function returns the value of the node at the front of the queue.
***********************************************************************************************/
Chracter* Queue::getFront()
{
	if (isEmpty())
	{
		cout << "Queue is empty." << endl;
		return NULL;
	}
	
	return  head->player;                   // need to modify this only need the name of the player.

}
/********************************************************************************************

						Queue::removeFront
This function removes the front QueueNode of the queue and free the memory.
***********************************************************************************************/

void Queue::removeFront()
{

	QueueNode *temp = head;
	if (isEmpty())
	{
		cout << "Queue is empty." << endl;
		return;
	}

	else if ( head->next == head)   // queue is not empty and has one element.
	{
		head = NULL;
		delete temp;
	}
	else // check if queue is not empty and has more than one element.
	{
		head = temp->next;
		head->prev = temp->prev;
		head->prev->next = head;
		delete temp;
	}
}

/********************************************************************************************

								Queue::printQueue
This function  traverses through the queue from head using next pointers, and prints 
the values of each QueueNode in the queue.
***********************************************************************************************/

void Queue::printQueue()
{
	QueueNode *temp = head;
	if (isEmpty())
	{
		cout << "Empty queue." << endl;
		return;
	}
	//cout << "The queue is :" << endl;
	while (temp->next != head)
	{
		cout << temp->player->getName() << " ";                    // need to modify this only name of the player to be displayed.
		temp = temp->next;
	}
	cout << temp->player->getName() << " " << endl;
}




