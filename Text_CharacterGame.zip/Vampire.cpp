/**************************************************************************
** Name: Aseem Prashar
** Date: 02/08/18
** Description: Vampire.cpp is the Vampire class implementation file.
***************************************************************************/

#include"Vampire.hpp"
#include<ctime>
#include<cstdlib>
#include<iostream>

using namespace std;

Vampire::Vampire()
{
	attack = 0;
	defense = 0;
	armor = 1;
	strengthPoints = 18;
	type = "Vampire";
}

Vampire::Vampire(string n)
{
	attack = 0;
	defense = 0;
	armor = 1;
	strengthPoints = 18;
	setName(n);
	type = "Vampire";
}


/*****************************************************************************************************
Vampire::Attack
This function returns the attack die roll.

******************************************************************************************************/

int Vampire::Attack()
{
	//1d12
	die = 1; // 1d12 die.
	attack = dieRoll();
	
	return attack;

}

/*****************************************************************************************************
Vampire::Defense
This function returns the defense die roll.

******************************************************************************************************/

int Vampire::Defense()
{
	//1d6
	charm = VampCharm();
	if (charm == 1)
	{
		//cout << " Vampire Charm is active." << endl;
		defense = 1000;
		return defense;
	}
	die = 2;
	defense = dieRoll();
	return defense;
}

/*****************************************************************************************************
Vampire::dieRoll
This function returns a random number between 1 and 12 if die=1. otherwise, it returns 
a random number between 1 and6.

******************************************************************************************************/

int Vampire::dieRoll()
{
	//srand(time(NULL));  // seed the random number for rand.)
	int num;
	if (die == 1)
	{
		num = rand() % 12 + 1; // random number between 1 and 12.
		//cout << "I am called from attack.Num is : " << num<< endl;
	}
	else
	{
		num = rand() % 6 + 1; // random number between 1 and 6.
		//cout << "I am called from defense.Num is : " << num << endl;
	}
	return num;

}


/*****************************************************************************************************
Vampire::getStrength
This function returns strength.

******************************************************************************************************/

double Vampire::getStrength()
{
	return strengthPoints;
}

/*****************************************************************************************************
Vampire::attackType()
This function displays attacker.

******************************************************************************************************/

void Vampire::attackType()
{
	cout << "The attack type is : Vampire" << endl;
}

/*****************************************************************************************************
Vampire::defendType
This function displays defender.
******************************************************************************************************/

void Vampire::defendType()
{
	cout << "The defense type is : Vampire" << endl;
}
/*****************************************************************************************************
Vampire::setStrength
This function takes an arguement to set strength.
******************************************************************************************************/

void Vampire::setStrength(double strength)
{
	strengthPoints = strength;
}
/*****************************************************************************************************
Vampire::setAttack
This function takes an arguement to set attack.
******************************************************************************************************/
void Vampire::setAttack(int a)
{
	attack = a;
}
/***************************************************************************************************
Vampire:: VampCharm 
This function returns a random number between 1 and 2 to check if charm is active or not.


*******************************************************************************************************/
int Vampire::VampCharm()
{
	charm = 0;
	charm = rand() % 2 + 1;
	//cout << "the charm is : " << charm << endl;
	return charm;
}

/******************************************************************************************************
								Vampire::recovery
This function generates a random number between 1 and 10 and based on that the player gains strength back.
Ex : 4 means 40% recovery from the damage to the strength.

*******************************************************************************************************/

void Vampire::recovery()
{
	int num = 0;

	if ((18 - getStrength()) > 0)
	{
		num = rand() % 10 + 1;                          // generate a random number between 1 and 10.
														//num = 5;
		//cout << "num is :" << num;
		double newStrength = getStrength() + ((18 - getStrength())*(num * 0.1));
		//cout << "New strength is : " << newStrength << endl;
		setStrength(newStrength);
	}
}