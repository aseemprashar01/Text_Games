/********************************************************************************************
** Name: Aseem Prashar
** Date: 2/08/18
** Description: Vampire.hpp is the Vampire class specification file.
********************************************************************************************/

#include"Chracter.hpp"

#ifndef VAMPIRE_HPP
#define VAMPIRE_HPP

class Vampire:public Chracter
{
	int die;         // 1- 1d12 2 for 1d6.
	int charm;       // 1-Charm is active and 2 charm is not active.
public:
	Vampire();
	Vampire(string n);
	int Attack();
	int Defense();
	int dieRoll();
	double getStrength();
	void attackType();
	void defendType();
	void setStrength(double);
	void setAttack(int);
	int VampCharm();
	void recovery();
};
#endif
