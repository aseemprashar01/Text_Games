/**************************************************************************
** Name: Aseem Prashar
** Date: 02/08/18
** Description: HarryPotter.cpp is the HarryPotter class implementation file.
***************************************************************************/

#include"HarryPotter.hpp"
#include<ctime>
#include<cstdlib>
#include<iostream>

using namespace std;

HarryPotter::HarryPotter()                                    // Constructor.
{
	attack = 0;
	defense = 0;
	armor = 0;
	strengthPoints = 10;
	life = 1; //life at start is 1. but can use hogwarts to come back to life with strengthPoints =20.
	type = "Harry Potter";
}

HarryPotter::HarryPotter(string n)                                    // Constructor.
{
	attack = 0;
	defense = 0;
	armor = 0;
	strengthPoints = 10;
	life = 1; //life at start is 1. but can use hogwarts to come back to life with strengthPoints =20.
	setName(n);
	type = "Harry Potter";
}


/*****************************************************************************************************
HarryPotter::Attack
This function returns the attack die roll.

******************************************************************************************************/
int HarryPotter::Attack()
{//2d6 
	attack = 0;
	for (int i = 0; i < 2; i++)
	{
		attack += dieRoll();
	}
	return attack;
}

/*****************************************************************************************************
HarryPotter::Defense
This function returns the defense die roll.

******************************************************************************************************/
int HarryPotter::Defense()
{//2d6
	defense = 0;
	for (int i = 0; i < 2; i++)
	{
		defense += dieRoll();
	}
	return defense;
}

/*****************************************************************************************************
HarryPotter::dieRoll
This function returns a random number between 1 and 6.

******************************************************************************************************/
int HarryPotter::dieRoll()
{
	//srand(time(NULL));  // seed the random number for rand.)
	int num;

	num = rand() % 6 + 1; // random number between 1 and 6.

	//cout << "Num is : " << num << endl;

	return num;

}


/*****************************************************************************************************
HarryPotter::getStrength
This function returns strength.

******************************************************************************************************/
double HarryPotter::getStrength()
{
	if (strengthPoints <= 0 && life == 1)
	{
		//cout << "HarryPotter used hogwarts." << endl;
		setStrength(20);
		life--;
	}
	return strengthPoints;
}

/*****************************************************************************************************
HarryPotter::attackType()
This function displays attacker.

******************************************************************************************************/
void HarryPotter::attackType()
{
	cout << "The attack type is : HarryPotter" << endl;
}

/*****************************************************************************************************
HarryPotter::defendType
This function displays defender.
******************************************************************************************************/
void HarryPotter::defendType()
{
	cout << "The defense type is : HarryPotter" << endl;
}

/*****************************************************************************************************
HarryPotter::setStrength
This function takes an arguement to set strength.
******************************************************************************************************/
void HarryPotter::setStrength(double strength)
{
	strengthPoints = strength;
}

/*****************************************************************************************************
HarryPotter::setAttack
This function takes an arguement to set attack.
******************************************************************************************************/
void HarryPotter::setAttack(int a)
{
	attack = a;
}
/******************************************************************************************************
								HarryPotter::recovery
This function generates a random number between 1 and 10 and based on that the player gains strength back.
Ex : 4 means 40% recovery from the damage to the strength.
When life is 1.Strength gained can be upto 10.
When life is 0.Strength gained can be upto 20.
*******************************************************************************************************/
void HarryPotter::recovery()
{
	int num = 0;
	

	if (life == 1)
	{
		if ((10 - getStrength()) > 0)
		{
			num = rand() % 10 + 1;                          // generate a random number between 1 and 10.
			//cout << "num is :" << num;
			double newStrength = getStrength() + ((10 - getStrength())*(num * 0.1));
			//cout << "New strength is : " << newStrength << endl;
			setStrength(newStrength);
		}
		

	}
	else if (life == 0)                                                           // Now life is 0.Harry potter has used hogwarts.
	{
		if (20 - getStrength() > 0)
		{
			num = rand() % 10 + 1;                          // generate a random number between 1 and 10.
			//cout << "num is :" << num;
			double newStrength = getStrength() + ((20 - getStrength())*(num * 0.1));
			//cout << "New strength is : " << newStrength << endl;
			setStrength(newStrength);
		}
		
	}
											
}