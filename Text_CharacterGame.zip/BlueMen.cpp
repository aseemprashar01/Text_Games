/**************************************************************************
** Name: Aseem Prashar
** Date: 02/08/18
** Description: BlueMen.cpp is the BlueMen class implementation file.
***************************************************************************/

#include"BlueMen.hpp"
#include<ctime>
#include<cstdlib>
#include<iostream>

using namespace std;


BlueMen::BlueMen()                          // Constructor.
{
	attack = 0;
	defense = 0;
	armor = 3;
	strengthPoints = 12;
	type = "Blue Men";
}

BlueMen::BlueMen(string n)                          // Constructor.
{
	attack = 0;
	defense = 0;
	armor = 3;
	strengthPoints = 12;
	setName(n);
	type = "Blue Men";
}
/*****************************************************************************************************
BlueMen::Attack
This function returns the attack die roll.

******************************************************************************************************/
int BlueMen::Attack()
{
	//2d10
	die = 1; //d10.
	attack = 0;
	for (int i = 0; i < 2; i++)
	{
		attack += dieRoll();
	}
	return attack;
}
/*****************************************************************************************************
BlueMen::Defense
This function returns the defense die roll.

******************************************************************************************************/
int BlueMen::Defense()
{
	die = 2;//3d6 . 6 sided die.
	defense = 0;
	
	if (getStrength() >8 && getStrength() <= 12)         // Strength between 8 and 12. Use 3d6.
	{
		defenseDie = 3; //3d6 die.
		//cout << "Using die 3d6." << endl;
		for (int i = 0; i < 3; i++)
		{
			defense += dieRoll();
		}
		return defense;
	}
	else if (getStrength() > 4 && getStrength() <= 8)  // Strength  between 4 and 8. Use 2d6.
	{
		defenseDie = 2;// 2d6 die.
		//cout << "Using die 2d6." << endl;
		for (int i = 0; i < 2; i++)
		{
			//cout << "Blue Men is defending with 2 six sided die." << endl;
			defense += dieRoll();
		}
		return defense;
	}
	else
	{
		defenseDie = 1; //1d6 die.
		//cout << "Using die 1d6." << endl;
		//cout << "Blue Men is defending with 1 six sided die." << endl;
		defense = dieRoll();
		return defense;
	}
	
}

/*****************************************************************************************************
BlueMen::dieRoll
This function returns a random number between based on diffrent die used. If die=1 random 
number between 1 and 10. otherwise random number between 1 and 6.


******************************************************************************************************/
int BlueMen::dieRoll()
{
	//srand(time(NULL));  // seed the random number for rand.)
	int num;
	if (die == 1)
	{
		num = rand() % 10 + 1; // random number between 1 and 10.
		//num = 5;
		//cout << "I am called from attack.Num is : " << num << endl;
	}
	else
	{
		num = rand() % 6 + 1; // random number between 1 and 6.
		
		//cout << "I am called from defense.Num is : " << num << endl;
	}
	return num;

}


/*****************************************************************************************************
BlueMen::getStrength
This function returns strength.

******************************************************************************************************/
double BlueMen::getStrength()
{
	return strengthPoints;
}

/*****************************************************************************************************
BlueMen::attackType()
This function displays attacker.

******************************************************************************************************/
void BlueMen::attackType()
{
	cout << "The attack type is : BlueMen" << endl;
}

/*****************************************************************************************************
BlueMen::defendType
This function displays defender.
******************************************************************************************************/
void BlueMen::defendType()
{
	cout << "The defense type is: BlueMen" << endl;
}

/*****************************************************************************************************
BlueMen::setStrength
This function takes an arguement to set strength.
******************************************************************************************************/
void BlueMen::setStrength(double strength)
{
	strengthPoints = strength;
}

/*****************************************************************************************************
BlueMen::setAttack
This function takes an arguement to set attack.
******************************************************************************************************/
void BlueMen::setAttack(int a)
{
	attack = a;
}
/******************************************************************************************************
								BlueMen::recovery
This function generates a random number between 1 and 10 and based on that the player gains strength back.
Ex : 4 means 40% recovery from the damage to the strength.

*******************************************************************************************************/


void BlueMen::recovery()
{
	int num = 0;

	if ((12 - getStrength()) > 0)
	{
		num = rand() % 10 + 1;                          // generate a random number between 1 and 10.
														//num = 5;
		//cout << "num is :" << num;
		double newStrength = getStrength() + ((12 - getStrength())*(num * 0.1));
		//cout << "New strength is : " << newStrength << endl;
		setStrength(newStrength);
	}
}